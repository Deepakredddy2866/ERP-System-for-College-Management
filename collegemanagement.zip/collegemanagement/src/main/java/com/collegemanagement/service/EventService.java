package com.collegemanagement.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.collegemanagement.entity.Event;
import com.collegemanagement.entity.EventRepo;


	@Service
	public class EventService {
		

			@Autowired
			EventRepo evrepo;
			
			public Event addNewEvent(Event event)
			{
				return evrepo.save(event);
			}
			
			public List<Event> getAllEvent()
			{
				return evrepo.findAll();
			}
			public void removeEventDetails(Event event)
			{
				evrepo.deleteById(event.getEvid());
			}

			

	}



