package com.collegemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.entity.PackageDetails;
import com.collegemanagement.entity.PackageDetailsRepo;



@Service
public class PackageDetailsService {
	@Autowired
	PackageDetailsRepo prepo;
	
	public List<PackageDetails> getAllPackages()
	{
		return prepo.findAll();
	}
	
	public PackageDetails addNewPackage(PackageDetails packages)
	{
		return prepo.save(packages);
	}
	public PackageDetails editPackageDetails(PackageDetails packages)
	{
		PackageDetails p1=prepo.getById(packages.getPid());
		p1.setPname(packages.getPname());
		p1.setPstudentattendance(packages.getPstudentattendance());
		p1.setPstudenttimetable(packages.getPstudenttimetable());
		p1.setPfacultyname(packages.getPfacultyname());
		p1.setPfacultypassword(packages.getPfacultypassword());
		p1.setPlibrarianname(packages.getPlibrarianname());
		p1.setPlibrarianpassword(packages.getPfacultypassword());
		p1.setPbookname(packages.getPbookname());
		p1.setPbookauthor(packages.getPbookauthor());
		p1.setPbookprice(packages.getPbookprice());
		prepo.save(p1);
		return p1;
	}
	
	public void removePackageDetails(PackageDetails packages)
	{
		prepo.deleteById(packages.getPid());
	}
}
