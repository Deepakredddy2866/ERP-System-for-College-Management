package com.collegemanagement.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.entity.Timetable;
import com.collegemanagement.entity.TimetableRepo;




@Service
public class TimetableService {
	@Autowired
	TimetableRepo trepo;
	
	
	
	public List<Timetable> getTimetables()
	{
		return trepo.findAll();
	}
	
	
	public Timetable addNewTimetable(Timetable timetable)
	{
		return trepo.save(timetable);
	}
	public Timetable updateTimetable(Timetable timetable)
	{
		Timetable t1=trepo.searchTimetable(timetable.getId());
		t1.setTime(timetable.getTime());
		trepo.save(t1);
		return t1;
	}

	
}
