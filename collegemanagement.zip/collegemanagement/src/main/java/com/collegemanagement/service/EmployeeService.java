package com.collegemanagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.collegemanagement.entity.Employee;
import com.collegemanagement.entity.EmployeeRepo;


@Service
public class EmployeeService {
	

		@Autowired
		EmployeeRepo erepo;
		
		public Employee addNewEmployee(Employee employee)
		{
			return erepo.save(employee);
		}
		
		public List<Employee> getAllEmployee()
		{
			return erepo.findAll();
		}
		
		public Employee updateEmployee(Employee employee)
		{
			Employee e3=erepo.getById(employee.getEid());
			e3=employee;
			e3.setEname(employee.getEname());
			e3.setEmail(employee.getEmail());
			e3.setEsubject(employee.getEsubject());
			e3.setEdepartment(employee.getEdepartment());
			e3.setEcontact(employee.getEcontact());
			erepo.save(e3);
			return e3;
			
		}
		public void removeEmployeeDetails(Employee employee)
		{
			erepo.deleteById(employee.getEid());
		}

}
