package com.collegemanagement.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.entity.Exam;
import com.collegemanagement.entity.ExamRepo;


@Service
public class ExamService {
	
			@Autowired
			ExamRepo exrepo;
			
			public Exam addNewExam(Exam exam)
			{
				return exrepo.save(exam);
			}
			
			public List<Exam> getAllExam()
			{
				return exrepo.findAll();
			}
			public Exam updateExam(Exam exam)
			{
				Exam ee3=exrepo.getById(exam.getExid());
				ee3=exam;
				exrepo.save(ee3);
				return ee3;
			}
			
			

	}


