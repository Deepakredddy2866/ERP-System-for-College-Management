package com.collegemanagement.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties ({"hibernateLazyInitializer"})
@Entity
public class Book implements Serializable{
	private static final long serialVersionUID = 1L;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int id;
	private String Pbookname;
	private String Pbookauthor;
	private int Pbookprice;
	public Book(int id, String pbookname, String pbookauthor, int pbookprice) {
		super();
		this.id = id;
		Pbookname = pbookname;
		Pbookauthor = pbookauthor;
		Pbookprice = pbookprice;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPbookname() {
		return Pbookname;
	}
	public void setPbookname(String pbookname) {
		Pbookname = pbookname;
	}
	public String getPbookauthor() {
		return Pbookauthor;
	}
	public void setPbookauthor(String pbookauthor) {
		Pbookauthor = pbookauthor;
	}
	public int getPbookprice() {
		return Pbookprice;
	}
	public void setPbookprice(int pbookprice) {
		Pbookprice = pbookprice;
	}
	
	

}
