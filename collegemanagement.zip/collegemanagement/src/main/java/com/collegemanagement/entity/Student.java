package com.collegemanagement.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "student")

public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int id;
	private String name;
	private String emailid;
	private String password;
	private String contact;
	private String department;
	private int batch;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Pid")
	private PackageDetails Pdetails;
	public Student() {}
	
  
	public Student(int id, String name, String emailid, String password, String contact, String department, int batch,
			PackageDetails pdetails) {
		super();
		this.id = id;
		this.name = name;
		this.emailid = emailid;
		this.password = password;
		this.contact = contact;
		this.department = department;
		this.batch = batch;
		Pdetails = pdetails;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public int getBatch() {
		return batch;
	}


	public void setBatch(int batch) {
		this.batch = batch;
	}


	public PackageDetails getPdetails() {
		return Pdetails;
	}


	public void setPdetails(PackageDetails pdetails) {
		Pdetails = pdetails;
	}

     



		
}
