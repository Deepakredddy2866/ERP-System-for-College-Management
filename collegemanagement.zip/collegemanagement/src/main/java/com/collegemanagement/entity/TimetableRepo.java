package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TimetableRepo extends JpaRepository<Timetable, Integer> {

	@Query(value=("select * from timetable where timetable.Id= ? "), nativeQuery = true)
	public Timetable searchTimetable(int Id);
}
