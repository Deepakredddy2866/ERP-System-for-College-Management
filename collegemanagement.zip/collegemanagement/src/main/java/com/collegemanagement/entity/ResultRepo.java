package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultRepo extends JpaRepository<Result, Integer>{

	

}
