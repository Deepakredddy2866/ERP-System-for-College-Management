package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.collegemanagement.entity.Event;
import com.collegemanagement.service.EventService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/eventcollegemanagement")
	public class EventController {
		 @Autowired
		 
		private EventService eventService;
		
		@GetMapping("/event/list")
		public List<Event> listevent()
		{
			return eventService.getAllEvent();
		}
		
		@PostMapping("/event/insert")
		public Event Addevent(@RequestBody Event event)
		{
			return eventService.addNewEvent(event);
		}
		@PutMapping("/student/remove")
		public void removeEvent(@RequestBody Event event)
		{
			eventService.removeEventDetails(event);
		}
	}



