package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.collegemanagement.entity.Timetable;
import com.collegemanagement.service.TimetableService;



@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/collegemanagement")
public class TimetableController {
	@Autowired
	private TimetableService timetableService;
	
	@PostMapping("/timetable/insert")
	public Timetable addTimetable(@RequestBody Timetable timetable)
	{
		return timetableService.addNewTimetable(timetable);
	}
	
	
	@GetMapping("/timetable/list")
	public List<Timetable> listTimetables()
	{
		return timetableService.getTimetables();
	}
	
	@PutMapping("/timetable/updatepwd")
	public Timetable updatePwd(@RequestBody Timetable timetable)
	{
		return timetableService.updateTimetable(timetable);
	}
}
