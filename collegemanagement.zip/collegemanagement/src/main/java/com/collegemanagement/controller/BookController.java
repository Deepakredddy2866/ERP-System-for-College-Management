package com.collegemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.collegemanagement.entity.Book;
import com.collegemanagement.entity.BookRequest;
import com.collegemanagement.service.BookService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/collegemanagement/book")
public class BookController {
  @Autowired
  BookService bService;
  
  @PostMapping("/add")
	public Book addBook(@RequestBody Book book)
	{
		return bService.addNewBook(book);
	}
  @GetMapping("/list")
	public List<Book> listBook()
	{
		return bService.getAllBooks();
	}
  @GetMapping("/by-id")
  public Book getBookById(@RequestParam int bookId) {
	 return bService.getBookById(bookId);
  }
  @PostMapping("/request")
  public String requestBook(@RequestParam int bookId ,@RequestParam int studentId) {
	  bService.requestBook(bookId ,studentId);
	  return "success";
  }
  @GetMapping("/list-request")
 	public List<BookRequest> listBookRequests()
 	{
 		return bService.getAllBookRequests();
 	}
  
  @GetMapping("/request-by-student")
  public List<BookRequest> listBookRequestByStudent(@RequestParam int studentId)
	{
		return bService.getAllBookRequestByStudent(studentId);
	}
  
}
