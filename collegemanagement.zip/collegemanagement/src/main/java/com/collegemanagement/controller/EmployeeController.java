package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.collegemanagement.entity.Employee;
import com.collegemanagement.service.EmployeeService;


	@CrossOrigin(origins="http://localhost:4200")
	@RestController
	@RequestMapping(path="/collegemanagement/employee")
	public class EmployeeController {
		@Autowired
		private EmployeeService employeeService;
		
		@GetMapping("/list")
		public List<Employee> listemployee()
		{
			return employeeService.getAllEmployee();
		}
		
		@PostMapping("/add")
		public Employee Addemployee(@RequestBody Employee employee)
		{
			return employeeService.addNewEmployee(employee);
		}
		
		@PostMapping("/edit")
		public Employee updateEmployee(@RequestBody Employee employee)
		{
			return employeeService.updateEmployee(employee);
		}
		
		@PutMapping("/delete")
		public void removeStudent(@RequestBody Employee employee)
		{
			employeeService.removeEmployeeDetails(employee);
		}
	}



