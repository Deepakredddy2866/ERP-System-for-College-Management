package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.collegemanagement.entity.Admin;
import com.collegemanagement.entity.Employee;
import com.collegemanagement.entity.Student;
import com.collegemanagement.service.AdminService;



@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/collegemanagement/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/add-admin")
	public Admin addAdmin(@RequestBody Admin admin)
	{
		return adminService.addNewAdmin(admin);
	}
	
	@GetMapping("list")
	public List<Admin> listAdmin()
	{
		return adminService.getAllAdmin();
	}
	
	@PutMapping("/update-password")
	public Admin updatePwd(@RequestBody Admin admin)
	{
		return adminService.updateAdmin(admin);
	}
	@PostMapping("/add-student")
	public Student addStudent(@RequestBody Student student)
	{
		return adminService.addNewStudent(student);
	}
	@GetMapping("/student-list")
	public List<Student> listStudents()
	{
		return adminService.getAllStudent();
	}
	
	@GetMapping("/employee-list")
	public List<Employee> listemployee()
	{
		return adminService.getAllEmployee();
	}
	
	@PostMapping("/add-employee")
	public Employee Addemployee(@RequestBody Employee employee)
	{
		return adminService.addNewEmployee(employee);
	}
}
