package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.collegemanagement.entity.Exam;
import com.collegemanagement.service.ExamService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/examcollegemanagement")
public class ExamController {
	 @Autowired
	 
		private ExamService examService;
		
		@GetMapping("/exam/list")
		public List<Exam> listexam()
		{
			return examService.getAllExam();
		}
		
		@PostMapping("/exam/insert")
		public Exam Addexam(@RequestBody Exam exam)
		{
			return examService.addNewExam(exam);
		}
		@PostMapping("/Exam/update")
		public Exam updateExam(@RequestBody Exam exam)
		{
			return examService.updateExam(exam);
		}

}
