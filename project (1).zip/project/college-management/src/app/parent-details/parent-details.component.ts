import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-parent-details',
  templateUrl: './parent-details.component.html',
  styleUrls: ['./parent-details.component.css']
})
export class ParentDetailsComponent implements OnInit {

  facultyData: any;
  constructor(private faculty: LoginService) {}

  ngOnInit(): void {
    this.faculty.getfaculty().subscribe((data) => {
      this.facultyData = data;
    });
  }

}
