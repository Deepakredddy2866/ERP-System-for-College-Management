import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  
  user: any;
  profileData:any;
  constructor(private profile:LoginService) {}

  ngOnInit(): void {
    const data: any = localStorage.getItem('user');
    this.user = JSON.parse(data);
    console.log(this.user);
    
    this.profile.getprofile().subscribe((data)=>{
      this.profileData = data;
    });
  }
}
