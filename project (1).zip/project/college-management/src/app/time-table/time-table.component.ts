import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';


@Component({
  selector: 'app-time-table',
  templateUrl: './time-table.component.html',
  styleUrls: ['./time-table.component.css']
})
export class TimeTableComponent implements OnInit {
 timetableData:any;
  constructor(private timetable:LoginService) { }

  ngOnInit(): void {
  
  this.timetable.gettimetable().subscribe((data)=>{
    this.timetableData = data;
  });
}

}
